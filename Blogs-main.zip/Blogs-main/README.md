﻿# Blog website
 This is a simple blog website where you can upload your blogs, delete your own blog, interact with your and others blog you can like comment, you can send feedback if you have any. 
Admin can view feedback and delete others blog

Create one database in mysql which should include 2 tables. You can use mysql

1. user - id,name,password,description,dob
2. blog - id,title,author,content,img
3. admin - admin_id, admin_password
4. contact - fname, lname, country, subject 
5. likes - id, post_id, user_id
6. comments - id, post_id, user_id, comment, ceeated_at
   
These are the tables and the values which are needed for this website
