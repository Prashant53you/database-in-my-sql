<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="heading">
            <h1>Insightful Ink</h1><br>
        </div>
        <nav>
            <ul>
                <li><a class="active" href="content.php">Home</a></li>
                <li><a href="upload.php">Click Here To Upload Your Blog</a></li>                
                <li><a href="logout.php">Logout</a></li>
                
            </ul>
        </nav>
    </header>
</body>
</html>



