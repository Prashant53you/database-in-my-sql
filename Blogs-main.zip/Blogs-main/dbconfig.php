<?php
$conn = new mysqli("localhost", "root", "", "blogwebsite");
?>
