<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    
<?php include 'header.html';?>

    <section class="about-us">
        
        <p>
          <h3>Welcome to our website! We are glad to have you here. Our platform offers a variety of features and services to cater to your needs. Whether you are a regular user or an administrator, we have something for you.<br>
          We have wide variety of blogs in our website you can go through it and can even create your own blogs here.</h3> 
        </p>
    </section>

    <?php include 'footer.html';?>
    
</body>
</html>
